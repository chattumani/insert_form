
<?php
    $conn = mysqli_connect('localhost:3306', 'peoplesu_student_regist', 'people@123', 'peoplesu_student_registration');

    if (!$conn) {
     echo "Error: Unable to connect to MySQL." . PHP_EOL;
     echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
     echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
     exit;
    }

   if(isset($_POST['submit'])){
        $myName = strtoupper($_POST['myName']);
        $last_name	 = strtoupper($_POST['last_name']);
        $f_name = strtoupper($_POST['f_name']);
        $batch = strtoupper($_POST['batch']);
        $pg = strtoupper($_POST['pg']);
        $speciality = strtoupper($_POST['speciality']);
		$suprspeciity = strtoupper($_POST['suprspeciity']);
		$c_employment = strtoupper($_POST['c_employment']);
		$previous = strtoupper($_POST['previous']);
		$hobby = strtoupper($_POST['hobby']);
		$contact = strtoupper($_POST['contact']);

if($myName !=''||$last_name !=''){
        $query = "INSERT INTO registration (myName,last_name,f_name,batch,pg,speciality,suprspeciity,c_employment,previous,hobby,contact) 
		VALUES('$myName','$last_name','$f_name','$batch','$pg','$speciality','$suprspeciity','$c_employment','$previous','$hobby','$contact')";
        echo '<script language="javascript">';
        echo 'alert("Successfully Registered");location.href="index.php"';
        echo '</script>';
		
}else{
echo "<script type='text/javascript'>alert('failed!')</script>";
}
		
		$sql = mysqli_query($conn, $query);
		 

    }

    mysqli_close($conn);
?>
<html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

</head>
<script>
$(document).ready(function(){
  $("form").submit(function(){
        alert("You have registered successfully");
        
  });
});
</script>
<script>
function relocate_home()
{
     location.href = "https://www.peoplesuniversity.edu.in/";
} 
</script>

<script>
$(document).ready(function(){
		$flag=1;
    	$("#myName").focusout(function(){
    		if($(this).val()==''){
        		$(this).css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			 $("#error_name").text("* You have to enter your  Name");
        	}
        	else
        	{
        		$(this).css("border-color", "#2eb82e");
        		$('#submit').attr('disabled',false);
        		$("#error_name").text("");

        	}
       });
     $("#last_name").focusout(function(){
    		if($(this).val()==''){
        		$(this).css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			$("#error_last_name").text("* You have to enter your Last Name");
        	}
        	else
        	{
        		$(this).css("border-color", "#2eb82e");
        		$('#submit').attr('disabled',false);
        		$("#error_last_name").text("");
        	}
       });
	   
        $("#f_name").focusout(function(){
    		if($(this).val()==''){
        		$(this).css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			$("#error_f_name").text("* You have to enter your Father Name");
        	}
        	else
        	{
        		$(this).css("border-color", "#2eb82e");
        		$('#submit').attr('disabled',false);
        		$("#error_f_name").text("");
        	}
       });
       
        $("#batch").focusout(function(){
    		if($(this).val()==''){
        		$(this).css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			$("#error_batch").text("* You have to enter your Batch ");
        	}
        	else
        	{
        		$(this).css({"border-color":"#2eb82e"});
        		$('#submit').attr('disabled',false);
        		$("#error_batch").text("");

        	}
        	});
			
			
			
			$("#contact").focusout(function(){
    		if($(this).val()==''){
        		$(this).css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			$("#error_contact").text("* Please enter Your Contact Number");
        	}
        	else
        	{
        		$(this).css({"border-color":"#2eb82e"});
        		$('#submit').attr('disabled',false);
        		$("#error_contact").text("");

        	}
        	});
			
			
			$("#nad_no").focusout(function(){
    		if($(this).val()==''){
        		$(this).css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			$("#error_nad_no").text("* Please enter Your NAD Number");
        	}
        	else
        	{
        		$(this).css({"border-color":"#2eb82e"});
        		$('#submit').attr('disabled',false);
        		$("#error_nad_no").text("");

        	}
        	});
			
			
			84*
			
		

   		$( "#submit" ).click(function() {
   			if($("#myName" ).val()=='')
   			{
        		$("#myName").css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			 $("#error_name").text("* You have to enter your name!");
        	}
        	if($("#last_name" ).val()=='')
   			{
        		$("#last_name").css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			 $("#error_last_name").text("* You have to enter your Lastname!");
        	}
   			if($("#f_name" ).val()=='')
   			{
        		$("#f_name").css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			 $("#error_f_name").text("* You have to enter your Father name!");
        	}
   			if($("#batch" ).val()=='')
   			{
        		$("#batch").css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			 $("#error_batch").text("* You have to enter your Batch!");
        	}
			
			
		
			if($("#contact" ).val()=='')
   			{
        		$("#contact").css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			 $("#error_contact").text("* Please Enter your Contact Number!");
        	}
			

        	
			});


    	
	});

	function isNumberKey(evt)
			{
				var charCode = (evt.which) ? evt.which : evt.keyCode;
				if (charCode != 46 && charCode > 31 
				&& (charCode < 48 || charCode > 57))
				return false;
				return true;
			}  
			
			
			function isNumericKey(evt)
			{
				var charCode = (evt.which) ? evt.which : evt.keyCode;
				if (charCode != 46 && charCode > 31 
				&& (charCode < 48 || charCode > 57))
				return true;
				return false;
			} 
			
			

</script>
<body>

<!--<div class="container-fluid">
  <h2></h2>  
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
   <div class="carousel-inner">
      <div class="item active">
        <img src="uploads/About-Sagar.jpg" alt="Los Angeles" style="width:100%;">
      </div>

    </div>
</div>
</div>-->
<div>&nbsp;</div>
<div class="container">
  
  <div class="row">
    <div class="col-sm-4 col-md-2" ><img src="logo.jpg" ></div>
    <div class="col-sm-4 col-md-8" ><p class="text-center" style="font-size: 30px; margin-top: 5px;font-weight: 600;color: #c62502;">
	People's College of Medical Sciences & Research Centre <br/>People's University, Bhopal</p>
	
	</div>
    <div class="col-sm-4 col-md-2" ><input type="button" class="btn btn-primary" value="University Home" onclick=" relocate_home()" style="background-color: #c62502;color: #FFF;border-radius: 50px;"></div>
    
  </div>
</div>
<hr/>
<div class="row">
    <div class="col-md-6 col-sm-12 col-lg-6 col-md-offset-3">
		
			<div class="panel-body">
				<form name="myform" method="POST" action="registration_detail.php" enctype="multipart/form-data">
			

				<div class="panel panel-primary">
			<div class="panel-heading text-center text-uppercase" >Alumni Registration Form
			</div>
				<div class="container-fluid">
				<div class="row">
				<div class="col-sm-6">
				<div class="form-group" >
					
						<label for="myName"> First Name *</label>
						<input id="myName" name="myName" style="text-transform: uppercase" class="form-control" type="text" data-validation="required" onkeypress="return isNumericKey(event)" required>
						<span id="error_name" class="text-danger"></span>
					</div></div>
				
				
					
					<div class="col-sm-6" >
					<div class="form-group">
						<label for="last_name">Last Name *</label>
						<input type="text" id="last_name"  name="last_name" class="form-control" style="text-transform: uppercase" onkeypress="return isNumericKey(event)" required>
						<span id="error_last_name" class="text-danger"></span>
					</div>
					</div>
					</div>
					
					<div class="row">
					
					<div class="col-sm-6" >
					<div class="form-group">
						<label for="f_name">Father’s Name *</label>
						<input id="f_name" name="f_name"  class="form-control" type="text" onkeypress="return isNumericKey(event)" style="text-transform: uppercase" onkeypress="return isNumericKey(event)" required>
						<span id="error_f_name" class="text-danger"></span>
					</div>
					</div>
					
					
					<div class="col-sm-6" >
					<div class="form-group">
						<label for="batch">UG Batch *</label>
							<select name="batch" id="batch" class="form-control" required>
									 <option>2005</option>
									 <option>2006</option>
									 <option>2007</option>
									 <option>2008</option>
									 <option>2009</option>
									 <option>2010</option>
									 <option>2011</option>
									 <option>2012</option>
									 <option>2013</option>
									 <option>2014</option>
									 <option>2015</option>
									
								  </select>
						<span id="error_batch" class="text-danger"></span>
					</div>
					</div>
					
					
					</div>
					
					<div class="row">
					
						<div class="col-sm-6" >
					<div class="form-group">
						<label for="pg">P.G </label>
						<select name="pg" class="form-control" >
						             <option>None</option>
									 <option>MD</option>
									 <option>MS</option>
									 <option>Diploma</option>
									 <option>DNB</option>
									 <option>Fellowship</option>
									
									
								  </select>
						<span id="error_pg" class="text-danger"></span>
					</div>
					</div>
					
					<div class="col-sm-6" >
					<div class="form-group">
						<label for="speciality">Speciality</label>
						<input id="speciality" name="speciality" class="form-control" type="text" data-validation="email" onkeypress="return isNumericKey(event)" style="text-transform: uppercase" >
						
						<span id="error_speciality" class="text-danger"></span>
					</div>
					</div>
					</div>
					
					
					<div class="row">
					
					<div class="col-sm-6" >
					<div class="form-group">
						<label for="suprspeciity">Superspeciality </label>
						<input id="suprspeciity" name="suprspeciity"  class="form-control" type="text"  style="text-transform: uppercase" onkeypress="return isNumericKey(event)" >
						<span id="error_suprspeciity" class="text-danger"></span>
					</div>
					</div>
					
					
					<div class="col-sm-6" >
					<div class="form-group">
						<label for="c_employment">Current Employment </label>
						<input id="c_employment" name="c_employment"  class="form-control" type="text"  style="text-transform: uppercase" onkeypress="return isNumericKey(event)" >
						<span id="error_c_employment" class="text-danger"></span>
					</div>
					</div>
					
					
				
					
					
					
					</div>
					
					<div class="row">
					
					<div class="col-sm-4" >
					<div class="form-group">
						<label for="previous">Previous Employment</label>
						<input id="previous" name="previous"  class="form-control" type="text"  style="text-transform: uppercase" onkeypress="return isNumericKey(event)" >
						<span id="error_previous" class="text-danger"></span>
					</div>
					</div>
					
					
					<div class="col-sm-4" >
					<div class="form-group">
						<label for="hobby">Hobbies </label>
						<input id="hobby" name="hobby"  class="form-control" type="text"  style="text-transform: uppercase" onkeypress="return isNumericKey(event)" >
						<span id="error_c_employment" class="text-danger"></span>
					</div>
					</div>
					
					
					<div class="col-sm-4" >
					<div class="form-group">
						<label for="contact">Contact No*</label>
						<input id="contact" name="contact"  class="form-control" type="text"  style="text-transform: uppercase" onkeypress="return isNumberKey(event)" required>
						<span id="error_contact" class="text-danger"></span>
					</div>
					</div>
					
					
					
					</div>
					
				
		<button  id="submit" type="submit" value="submit" name="submit" class="btn btn-primary center-block" >Submit</button>
			<!--<a href="https://www.peoplesuniversity.edu.in/Engineering/" class="btn btn-primary center-block" id="submit" type="submit" name="submit">Submit</a>-->
		
		
		
			
			
			
				</form>

			
		</div>
	</div>
	</div>
	</div>
	</div>
	
	

</body>
</html>