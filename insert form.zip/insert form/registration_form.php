<?php
//error_reporting(0);

require_once('phpmailer_5.2.4/class.phpmailer.php');
include("class.smtp.php"); // optional, gets called from within class.phpmailer.php  if not already loaded

$course = $_REQUEST["course"];
$branch = $_REQUEST["branch"];
$q_exam = $_REQUEST["q_exam"];
$category = $_REQUEST["category"];
$nationality = $_REQUEST["nationality"];
$gender = $_REQUEST["gender"];
$hostel = $_REQUEST["hostel"];
$bus = $_REQUEST["bus"];
$myName = $_REQUEST["myName"];
$hindi_name = $_REQUEST["hindi_name"];
$f_name = $_REQUEST["f_name"];
$date = $_REQUEST["date"];
$m_name = $_REQUEST["m_name"];
$religion = $_REQUEST["religion"];
$uid_no = $_REQUEST["uid_no"];
$nad_no = $_REQUEST["nad_no"];
$x_year = $_REQUEST["x_year"];
$x_marks = $_REQUEST["x_marks"];
$x_board = $_REQUEST["x_board"];
$x_state = $_REQUEST["x_state"];
$xii_year = $_REQUEST["xii_year"];
$xii_marks = $_REQUEST["xii_marks"];
$xii_board = $_REQUEST["xii_board"];
$xii_state = $_REQUEST["xii_state"];
$bsc_year = $_REQUEST["bsc_year"];
$bsc_marks = $_REQUEST["bsc_marks"];
$bsc_board = $_REQUEST["bsc_board"];
$bsc_state = $_REQUEST["bsc_state"];
$be_year = $_REQUEST["be_year"];
$be_marks = $_REQUEST["be_marks"];
$be_board = $_REQUEST["be_board"];
$be_state = $_REQUEST["be_state"];
$mca_year = $_REQUEST["mca_year"];
$mca_marks = $_REQUEST["mca_marks"];
$mca_board = $_REQUEST["mca_board"];
$xii_state = $_REQUEST["xii_state"];
$bsc_year = $_REQUEST["bsc_year"];
$others_year = $_REQUEST['others_year'];
$others_marks = $_REQUEST['others_marks'];
$others_board = $_REQUEST['others_board'];
$others_state = $_REQUEST['others_state'];
$address = $_REQUEST['address'];
$district = $_REQUEST['district'];
$state = $_REQUEST['state'];
$pincode = $_REQUEST['pincode'];
$email = $_REQUEST['email'];
$std_no = $_REQUEST['std_no'];
$whts_no = $_REQUEST['whts_no'];
$fatr_no = $_REQUEST['fatr_no'];
$othr_no = $_REQUEST['othr_no'];





$image = $_REQUEST["image"];
$filepath = "uploads/" . $_FILES["image"]["name"] . ".jpg";
$fullpath = "http://peoplesuniversity.edu.in/Engineering/uploads/" . $_FILES["image"]["name"] . ".jpg";
if(move_uploaded_file($_FILES["image"]["tmp_name"], $filepath)) 
{
//echo "<img src=".$filepath." height=100 width=80 />";
} 
else 
{
//echo "Error !!";
}


try {
date_default_timezone_set('UTC');
$mail = new PHPMailer();
$mail->Host ="smtp.gmail.com";   //"relay-hosting.secureserver.net"; // your SMTP Server
$mail->Port=587; // or 587
$mail->IsHTML(true);
$mail->IsSMTP();
$mail->SMTPDebug = 1;
$mail->SMTPAuth = true; // Auth Type
$mailfalseTPKeepAlive = true;  
$mail->SMTPSecure = 'tls'; 
$mail->Username = "noreply@peoplesuniversity.edu.in";
$mail->Password = "noreply@123";
$mail->Sender="info@peoplesuniversity.edu.in";
$mail->From = "info@peoplesuniversity.edu.in";
$mail->AddReplyTo("info@peoplesuniversity.edu.in");
$mail->FromName = "$name";
$mail->AddAddress("engg@peoplesuniversity.edu.in");
$mail->AddAddress="$email";
//$mail->AddAddress("santo.pasi23@gmail.com");	
$mail->IsHTML(true);
//$mail->AddEmbeddedImage('$filepath', 'logoimg', 'logo.jpg');


$to = $mail->From;

$email_subject = "Contact form submission";

$email_body = "Thank You ,You have registered successfully. ";

$headers = "From: $to\n";

$headers .= "Reply-To: $mail->AddAddress";

mail($mail->AddAddress,$email_subject,$email_body,$headers);

$mail->Subject = "Admission Enquiry";
$mail->Body = "
<html>
<head>
<title>Admission Enquiry</title>
</head>
<body>
<table style='border:1px solid; padding:20px; text-align:left'>
<tr>
<th>Photo</th>
<td>Click To View <br/> $fullpath</td>
</tr> 
<tr>
<th>Course:</th>
<td>$course</td>
</tr>
<tr>
<th>Branch:</th>
<td>$branch</td>
</tr>
<tr>
<th>Mobile:</th>
<td>$q_exam</td>
</tr>
<tr>
<th>Category:</th>
<td>$category</td>
</tr>
<tr>
<th>Nationality:</th>
<td>$nationality</td>
</tr>
<tr>
<th>Gender:</th>
<td>$gender</td>
</tr>
<tr>
<th>Hostel :</th>
<td>$hostel</td>
</tr>
<tr>
<th>Bus :</th>
<td>$bus</td>
</tr>
<tr>
<th>Name of the Student :</th>
<td>$myName</td>
</tr>
<tr>
<th>Name (In Hindi):</th>
<td>$hindi_name</td>
</tr>

<tr>
<th>Father’s Name:</th>
<td>$f_name</td>
</tr>
<tr>
<th>Date of Birth:</th>
<td>$date</td>
</tr>
<tr>
<th>Mother’s Name:</th>
<td>$m_name</td>
</tr>
<tr>
<th>Religion:</th>
<td>$religion</td>
</tr>
<tr>
<th>UID Number:</th>
<td>$uid_no</td>
</tr>
<tr>
<th>NAD ID Number:</th>
<td>$nad_no</td>
</tr>
<tr>
<th>X Passing Year:</th>
<td>$x_year</td>
</tr>
<tr>
<th>X Marks:</th>
<td>$x_marks</td>
</tr>
<tr>
<th>X Board/University:</th>
<td>$x_board</td>
</tr>
<tr>
<th>X State:</th>
<td>$x_state</td>
</tr>
<tr>
<th>XII/ITI Passing Year:</th>
<td>$xii_year</td>
</tr>
<tr>
<th>XII/ITI Marks:</th>
<td>$xii_marks</td>
</tr>
<tr>
<th>XII/ITI Board/University:</th>
<td>$xii_board</td>
</tr>
<tr>
<th>XII/ITI State:</th>
<td>$xii_state</td>
</tr>
<tr>
<th>Diploma/B.Sc Year:</th>
<td>$bsc_year</td>
</tr>
<tr>
<th>Diploma/B.Sc Marks:</th>
<td>$bsc_marks</td>
</tr>
<tr>
<th>Diploma/B.Sc Board/University:</th>
<td>$bsc_board</td>
</tr>
<tr>
<th>Diploma/B.Sc State:</th>
<td>$bsc_state</td>
</tr>
<tr>
<th>BE/B.Tech Passing Year:</th>
<td>$be_year</td>
</tr>
<tr>
<th>BE/B.Tech Marks:</th>
<td>$be_marks</td>
</tr>
<tr>
<th>BE/B.Tech Board/University:</th>
<td>$be_board</td>
</tr>
<tr>
<th>BE/B.Tech State:</th>
<td>$be_state</td>
</tr>
<tr>
<th>MCA Passing Year:</th>
<td>$mca_year</td>
</tr>
<tr>
<th>MCA Marks:</th>
<td>$mca_marks</td>
</tr>
<tr>
<th>MCA Board/University:</th>
<td>$mca_board</td>
</tr>
<tr>
<th>MCA State:</th>
<td>$mca_state</td>
</tr>

<tr>
<th>Others Passing Year:</th>
<td>$others_year</td>
</tr>
<tr>
<th>Others Marks:</th>
<td>$others_marks</td>
</tr>
<tr>
<th>Others Board/University:</th>
<td>$others_board</td>
</tr>
<tr>
<th>Others State:</th>
<td>$others_state</td>
</tr>
<tr>
<th>Permanent Address:</th>
<td>$address</td>
</tr>
<tr>
<th>District:</th>
<td>$district</td>
</tr>
<tr>
<th>State:</th>
<td>$state</td>
</tr>
<tr>
<th>Pin Code:</th>
<td>$pincode</td>
</tr>
<tr>
<th>Email-Id:</th>
<td>$email</td>
</tr>
<tr>
<th>Student Number:</th>
<td>$std_no</td>
</tr>
<tr>
<th>Whatsapp Number:</th>
<td>$whts_no</td>
</tr>
<tr>
<th>Father Number:</th>
<td>$fatr_no</td>
</tr>
<tr>
<th>Any other Number:</th>
<td>$othr_no</td>
</tr>

</table>
</body>
</html>
";
if($mail->Send()){
   // echo "<script>window.location='http://peoplesuniversity.edu.in/alumni/'</script>";
   //echo 'mail send'; 
     }else{
              echo 'mail not send'; 
           }
} catch (phpmailerException $e) {
//$e->errorMessage(); 
//Pretty error messages from PHPMailer
} catch (Exception $e) {
//$e->getMessage(); 
//Boring error messages from anything else!
}


?>
<html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

</head>
<script>
$(document).ready(function(){
  $("form").submit(function(){
        alert("You have registered successfully");
        
  });
});
</script>
<script>
function relocate_home()
{
     location.href = "https://www.peoplesuniversity.edu.in/";
} 
</script>

<script>
$(document).ready(function(){
		$flag=1;
    	$("#myName").focusout(function(){
    		if($(this).val()==''){
        		$(this).css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			 $("#error_name").text("* You have to enter your  Name");
        	}
        	else
        	{
        		$(this).css("border-color", "#2eb82e");
        		$('#submit').attr('disabled',false);
        		$("#error_name").text("");

        	}
       });
     $("#hindi_name").focusout(function(){
    		if($(this).val()==''){
        		$(this).css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			$("#error_hindi_name").text("* You have to enter your Hindi Name");
        	}
        	else
        	{
        		$(this).css("border-color", "#2eb82e");
        		$('#submit').attr('disabled',false);
        		$("#error_hindi_name").text("");
        	}
       });
	   
        $("#f_name").focusout(function(){
    		if($(this).val()==''){
        		$(this).css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			$("#error_f_name").text("* You have to enter your Father Name");
        	}
        	else
        	{
        		$(this).css("border-color", "#2eb82e");
        		$('#submit').attr('disabled',false);
        		$("#error_f_name").text("");
        	}
       });
       
        $("#date").focusout(function(){
    		if($(this).val()==''){
        		$(this).css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			$("#error_date").text("* You have to enter your Date of Birth");
        	}
        	else
        	{
        		$(this).css({"border-color":"#2eb82e"});
        		$('#submit').attr('disabled',false);
        		$("#error_date").text("");

        	}
        	});
			
			
			$("#m_name").focusout(function(){
    		if($(this).val()==''){
        		$(this).css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			$("#error_m_name").text("* You have to enter your mother Name");
        	}
        	else
        	{
        		$(this).css({"border-color":"#2eb82e"});
        		$('#submit').attr('disabled',false);
        		$("#error_m_name").text("");

        	}
        	});
			
			
			$("#religion").focusout(function(){
    		if($(this).val()==''){
        		$(this).css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			$("#error_religion").text("* You have to enter your Religion");
        	}
        	else
        	{
        		$(this).css({"border-color":"#2eb82e"});
        		$('#submit').attr('disabled',false);
        		$("#error_religion").text("");

        	}
        	});
			
			
			$("#uid_no").focusout(function(){
    		if($(this).val()==''){
        		$(this).css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			$("#error_uid_no").text("* Please enter Your UID Number");
        	}
        	else
        	{
        		$(this).css({"border-color":"#2eb82e"});
        		$('#submit').attr('disabled',false);
        		$("#error_uid_no").text("");

        	}
        	});
			
			
			$("#nad_no").focusout(function(){
    		if($(this).val()==''){
        		$(this).css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			$("#error_nad_no").text("* Please enter Your NAD Number");
        	}
        	else
        	{
        		$(this).css({"border-color":"#2eb82e"});
        		$('#submit').attr('disabled',false);
        		$("#error_nad_no").text("");

        	}
        	});
			
			
			84*
			
		

   		$( "#submit" ).click(function() {
   			if($("#myName" ).val()=='')
   			{
        		$("#myName").css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			 $("#error_name").text("* You have to enter your name!");
        	}
        	if($("#hindi_name" ).val()=='')
   			{
        		$("#hindi_name").css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			 $("#error_hindi_name").text("* You have to enter your Hindi name!");
        	}
   			if($("#f_name" ).val()=='')
   			{
        		$("#f_name").css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			 $("#error_f_name").text("* You have to enter your Father name!");
        	}
   			if($("#date" ).val()=='')
   			{
        		$("#date").css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			 $("#error_date").text("* You have to enter your Date of Birth!");
        	}
			
			
			if($("#m_name" ).val()=='')
   			{
        		$("#m_name").css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			 $("#error_m_name").text("* You have to enter your Mother name!");
        	}
			
			
			if($("#religion" ).val()=='')
   			{
        		$("#religion").css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			 $("#error_religion").text("* You have to enter your Religion!");
        	}
			
			if($("#uid_no" ).val()=='')
   			{
        		$("#uid_no").css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			 $("#error_uid_no").text("* Please Enter your UID Number!");
        	}
			
			if($("#nad_no" ).val()=='')
   			{
        		$("#nad_no").css("border-color", "#FF0000");
        			$('#submit').attr('disabled',true);
        			 $("#error_nad_no").text("* Please Enter your NAD Number!");
        	}
			
			
			
			/
			
			
        	
			});


    	
	});

	function isNumberKey(evt)
			{
				var charCode = (evt.which) ? evt.which : evt.keyCode;
				if (charCode != 46 && charCode > 31 
				&& (charCode < 48 || charCode > 57))
				return false;
				return true;
			}  
			
			
			function isNumericKey(evt)
			{
				var charCode = (evt.which) ? evt.which : evt.keyCode;
				if (charCode != 46 && charCode > 31 
				&& (charCode < 48 || charCode > 57))
				return true;
				return false;
			} 
			
			

</script>
<body>

<!--<div class="container-fluid">
  <h2></h2>  
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
   <div class="carousel-inner">
      <div class="item active">
        <img src="uploads/About-Sagar.jpg" alt="Los Angeles" style="width:100%;">
      </div>

    </div>
</div>
</div>-->
<div>&nbsp;</div>
<div class="container">
  
  <div class="row">
    <div class="col-sm-4 col-md-2" ><img src="logo.jpg" ></div>
    <div class="col-sm-4 col-md-8" ><p class="text-center" style="font-size: 30px; margin-top: 5px;font-weight: 600;color: #000837;">School of Research & Technology <br/>People's University, Bhopal</p></div>
    <div class="col-sm-4 col-md-2" ><input type="button" class="btn btn-primary" value="University Home" onclick=" relocate_home()" style="background-color: #243962;color: #FFF;border-radius: 50px;"></div>
  </div>
</div>
<hr/>
<div class="row">
    <div class="col-md-6 col-sm-12 col-lg-6 col-md-offset-3">
		
			<div class="panel-body">
				<form name="myform" method="POST" action="registration_form.php" enctype="multipart/form-data">
				<div class="row">
				<div class="col-sm-4" >
				<div class="form-group" >
					
						<label for="course"> Course *</label>
						<input id="course" name="course" style="text-transform: uppercase" class="form-control" type="text" data-validation="required" onkeypress="return isNumericKey(event)" required>
						<span id="error_course" class="text-danger"></span>
					</div></div>
				
				
					
					<div class="col-sm-4" >
					<div class="form-group">
						<label for="branch">Branch / Specialization) *</label>
						<input type="text" id="branch"  name="branch" class="form-control" style="text-transform: uppercase" required>
						<span id="error_branch" class="text-danger"></span>
					</div>
					</div>
					
					<div class="col-sm-4" >
					<div class="form-group">
						<label for="branch">Image Upload*</label>
						<input type="hidden" name="MAX_FILE_SIZE" value="100000" /> 
						<input name="image" type="file" value="Upload" /> 
						<span id="error_branch" class="text-danger"></span>
					</div>
					</div>
					</div>
					<div class="row">
				<div class="col-sm-6" >
				<div class="form-group" >
					
						<label for="q_exam"> Qualifying Exam *</label>
						<input id="q_exam" name="q_exam" style="text-transform: uppercase" class="form-control" type="text" data-validation="required" onkeypress="return isNumericKey(event)" required>
						<span id="error_q_exam" class="text-danger"></span>
					</div></div>
				
				
					
					<div class="col-sm-6" >
					<div class="form-group">
						<label for="category">Category *</label>
						<input type="text" id="category"  name="category" class="form-control" style="text-transform: uppercase">
						<span id="error_category" class="text-danger"></span>
					</div>
					</div>
					</div>
					<div class="row">
				<div class="col-sm-6" >
				<div class="form-group" >
					
						<label for="nationality"> Nationality *</label>
						<input id="nationality" name="nationality" style="text-transform: uppercase" class="form-control" type="text" data-validation="required" onkeypress="return isNumericKey(event)" required>
						<span id="error_nationality" class="text-danger"></span>
					</div></div>
				
				
					
					<div class="col-sm-6" >
					<div class="form-group">
						<label for="gender">Gender *</label>
						            <select name="gender" class="form-control" required>
									 <option>Male</option>
									 <option>Female</option>
								  </select>
						<span id="error_gender" class="text-danger"></span>
					</div>
					</div>
					</div>
					<div class="row">
				<div class="col-sm-6" >
				<div class="form-group" >
					
						<label for="hostel"> Hostel *</label>
						<input id="hostel" name="hostel" style="text-transform: uppercase" class="form-control" type="text" data-validation="required" onkeypress="return isNumericKey(event)" required>
						<span id="error_hostel" class="text-danger"></span>
					</div></div>
				
				
					
					<div class="col-sm-6" >
					<div class="form-group">
						<label for="bus">Bus *</label>
						<input type="text" id="bus"  name="bus" class="form-control" style="text-transform: uppercase" required>
						<span id="error_bus" class="text-danger"></span>
					</div>
					</div>
					</div>
				
				
				<div class="panel panel-info">
			<div class="panel-heading text-center text-uppercase" >PERSONAL DETAILS (*USE CAPITAL LETTERS ONLY)
			</div>
				<div class="container-fluid">
				<div class="row">
				<div class="col-sm-6" >
				<div class="form-group" >
					
						<label for="myName"> Name of the Student *</label>
						<input id="myName" name="myName" style="text-transform: uppercase" class="form-control" type="text" data-validation="required" onkeypress="return isNumericKey(event)" required>
						<span id="error_name" class="text-danger"></span>
					</div></div>
				
				
					
					<div class="col-sm-6" >
					<div class="form-group">
						<label for="hindi_name">Name (In Hindi) *</label>
						<input type="text" id="hindi_name"  name="hindi_name" class="form-control" style="text-transform: uppercase" required>
						<span id="error_hindi_name" class="text-danger"></span>
					</div>
					</div>
					</div>
					
					<div class="row">
					
					<div class="col-sm-6" >
					<div class="form-group">
						<label for="f_name">Father’s Name *</label>
						<input id="f_name" name="f_name"  class="form-control" type="text" onkeypress="return isNumberKey(event)" style="text-transform: uppercase" required>
						<span id="error_f_name" class="text-danger"></span>
					</div>
					</div>
					
					
					<div class="col-sm-6" >
					<div class="form-group">
						<label for="date">Date of Birth *</label>
						<input type="date" name="date" id="date" class="form-control">
						<span id="error_date" class="text-danger"></span>
					</div>
					</div>
					
					
					</div>
					
					<div class="row">
					
						<div class="col-sm-6" >
					<div class="form-group">
						<label for="m_name">Mother’s Name *</label>
						<input id="m_name" name="m_name"  class="form-control" type="text" onkeypress="return isNumberKey(event)" style="text-transform: uppercase" required>
						<span id="error_m_name" class="text-danger"></span>
					</div>
					</div>
					
					<div class="col-sm-6" >
					<div class="form-group">
						<label for="religion">Religion *</label>
						<input id="religion" name="religion" class="form-control" type="text" data-validation="email" onkeypress="return isNumericKey(event)" style="text-transform: uppercase" required>
						
						<span id="error_religion" class="text-danger"></span>
					</div>
					</div>
					</div>
					
					
					<div class="row">
					
					<div class="col-sm-6" >
					<div class="form-group">
						<label for="uid_no">UID Number  *</label>
						<input id="uid_no" name="uid_no"  class="form-control" type="text"  style="text-transform: uppercase" required>
						<span id="error_uid_no" class="text-danger"></span>
					</div>
					</div>
					
					
					<div class="col-sm-6" >
					<div class="form-group">
						<label for="nad_no">NAD ID Number  *</label>
						<input id="nad_no" name="nad_no"  class="form-control" type="text"  style="text-transform: uppercase" required>
						<span id="error_nad_no" class="text-danger"></span>
					</div>
					</div>
					
					
				
					
					
					
					</div>
					
				
			 <div class="panel-group">
    <div class="panel panel-info">
      <div class="panel-heading text-center text-uppercase">EDUCATIONAL QUALIFICATION</div>
      <div class="panel-body">
	  <table class="table table-bordered">
    <thead>
      <tr>
        <th>S.No</th>
        <th>Exam</th>
        <th>Passing Year</th>
		 <th>%Marks/ CGPA</th>
        <th>Board/University</th>
        <th>State</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>1</td>
        <td>X</td>
        <td><input id="x_year" name="x_year"  class="form-control" type="text"  style="text-transform: uppercase" required></td>
		<td><input id="x_marks" name="x_marks"  class="form-control" type="text"  style="text-transform: uppercase" required></td>
		<td><input id="x_board" name="x_board"  class="form-control" type="text"  style="text-transform: uppercase" required></td>
		<td><input id="x_state" name="x_state"  class="form-control" type="text"  style="text-transform: uppercase" required></td>
      </tr>
      <tr>
        <td>2</td>
        <td>XII/ITI</td>
        <td><input id="xii_year" name="xii_year"  class="form-control" type="text"  style="text-transform: uppercase" required></td>
		<td><input id="xii_marks" name="xii_marks"  class="form-control" type="text"  style="text-transform: uppercase" required></td>
		<td><input id="xii_board" name="xii_board"  class="form-control" type="text"  style="text-transform: uppercase" required></td>
		<td><input id="xii_state" name="xii_state"  class="form-control" type="text"  style="text-transform: uppercase" required></td>
      </tr>
      <tr>
        <td>3</td>
        <td>Diploma/B.Sc</td>
        <td><input id="bsc_year" name="bsc_year"  class="form-control" type="text"  style="text-transform: uppercase" required></td>
		<td><input id="bsc_marks" name="bsc_marks"  class="form-control" type="text"  style="text-transform: uppercase" required></td>
		<td><input id="bsc_board" name="bsc_board"  class="form-control" type="text"  style="text-transform: uppercase" required></td>
		<td><input id="bsc_state" name="bsc_state"  class="form-control" type="text"  style="text-transform: uppercase" required></td>
      </tr>
	   <tr>
        <td>4</td>
        <td>BE/B.Tech</td>
        <td><input id="be_year" name="be_year"  class="form-control" type="text"  style="text-transform: uppercase" required></td>
		<td><input id="be_marks" name="be_marks"  class="form-control" type="text"  style="text-transform: uppercase" required></td>
		<td><input id="be_board" name="be_board"  class="form-control" type="text"  style="text-transform: uppercase" required></td>
		<td><input id="be_state" name="be_state"  class="form-control" type="text"  style="text-transform: uppercase" required></td>
      </tr>
	   <tr>
        <td>5</td>
        <td>MCA</td>
        <td><input id="mca_year" name="mca_year"  class="form-control" type="text"  style="text-transform: uppercase" required></td>
		<td><input id="mca_marks" name="mca_marks"  class="form-control" type="text"  style="text-transform: uppercase" required></td>
		<td><input id="mca_board" name="mca_board"  class="form-control" type="text"  style="text-transform: uppercase" required></td>
		<td><input id="mca_state" name="mca_state"  class="form-control" type="text"  style="text-transform: uppercase" required></td>
      </tr>
	   <tr>
        <td>6</td>
        <td>Others</td>
        <td><input id="others_year" name="others_year"  class="form-control" type="text"  style="text-transform: uppercase" required></td>
		<td><input id="others_marks" name="others_marks"  class="form-control" type="text"  style="text-transform: uppercase" required></td>
		<td><input id="others_board" name="others_board"  class="form-control" type="text"  style="text-transform: uppercase" required></td>
		<td ><input id="others_state" name="others_state"  class="form-control" type="text"  style="text-transform: uppercase" required></td>
      </tr>
    </tbody>
  </table>
	  
	  
	  </div>
    </div>
					
		</div>	



	 <div class="panel-group">
    <div class="panel panel-info">
      <div class="panel-heading text-center text-uppercase">CORRESPONDANCE ADDRESS</div>
      <div class="panel-body">
	  	<div class="row">
					
					<div class="col-sm-5" >
					<div class="form-group">
						<label for="address">Permanent Address</label>
						<textarea name="address" class="form-control" rows="3"  style="text-transform: uppercase"></textarea>
						<span id="error_address" class="text-danger"></span>
					</div>
					</div>
					
					
					<div class="col-sm-4" >
					<div class="form-group">
						<label for="district">District</label>
						<input id="district" name="district"  class="form-control" type="text"  style="text-transform: uppercase" required>
						<span id="error_district" class="text-danger"></span>
					</div>
					</div>
					
					<div class="col-sm-3" >
					<div class="form-group">
						<label for="state">State</label>
						<input id="state" name="state"  class="form-control" type="text"  style="text-transform: uppercase" required>
						<span id="error_state" class="text-danger"></span>
					</div>
					</div>
					
					
				
					
					
					
					</div>
					<div class="row">
					
					<div class="col-sm-4" >
					<div class="form-group">
						<label for="pincode">Pin Code </label>
						<input id="pincode" name="pincode"  class="form-control" type="text"  style="text-transform: uppercase" required>
						<span id="error_pincode" class="text-danger"></span>
					</div>
					</div>
					
					
					<div class="col-sm-4" >
					<div class="form-group">
						<label for="email">Email-Id</label>
						<input id="email" name="email"  class="form-control" type="text"  style="text-transform: uppercase" required>
						<span id="error_email" class="text-danger"></span>
					</div>
					</div>
					
					<div class="col-sm-4" >
					<div class="form-group">
						<label for="std_no">Student Number</label>
						<input id="std_no" name="std_no"  class="form-control" type="text"  style="text-transform: uppercase" required>
						<span id="error_std_no" class="text-danger"></span>
					</div>
					</div>
					
					
				</div>
				<div class="row">
					
					<div class="col-sm-4" >
					<div class="form-group">
						<label for="whts_no">Whatsapp Number </label>
						<input id="whts_no" name="whts_no"  class="form-control" type="text"  style="text-transform: uppercase" required>
						<span id="error_whts_no" class="text-danger"></span>
					</div>
					</div>
					
					
					<div class="col-sm-4" >
					<div class="form-group">
						<label for="fatr_no">Father Number</label>
						<input id="fatr_no" name="fatr_no"  class="form-control" type="text"  style="text-transform: uppercase" required>
						<span id="error_fatr_no" class="text-danger"></span>
					</div>
					</div>
					
					<div class="col-sm-4" >
					<div class="form-group">
						<label for="othr_no">Any other Number</label>
						<input id="othr_no" name="othr_no"  class="form-control" type="text"  style="text-transform: uppercase" required>
						<span id="error_othr_no" class="text-danger"></span>
					</div>
					</div>
					
					
				</div>
	  
	  
	  </div>
    </div>
					
		</div>			
					
					
		<button  id="submit" type="submit" value="submit" name="submit" class="btn btn-primary center-block" >Submit</button>
			<!--<a href="https://www.peoplesuniversity.edu.in/Engineering/" class="btn btn-primary center-block" id="submit" type="submit" name="submit">Submit</a>-->
		
		
		
			
			
			
				</form>

			
		</div>
	</div>
	</div>
	</div>
	</div>
	
	

</body>
</html>